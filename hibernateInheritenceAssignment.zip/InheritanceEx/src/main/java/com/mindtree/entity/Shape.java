package com.mindtree.entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="Shape")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn
(
 name="Discriminator",
 discriminatorType=DiscriminatorType.STRING
)
@DiscriminatorValue(value="S")
public class Shape {
	
	@Id
	@GeneratedValue
	int shapeId;
	String shapeName;
	
	public Shape() {
		super();
		
	}
	public Shape(String shapeName) {
		super();
		this.shapeName = shapeName;
	}
	public String getShapeName() {
		return shapeName;
	}
	public void setShapeName(String shapeName) {
		this.shapeName = shapeName;
	}
	

}
