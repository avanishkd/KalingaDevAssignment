package com.mindtree.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "C")
public class Circle extends Shape {

	int radius;

	public Circle() {

	}

	public Circle(String shapeName, int radius) {
		super(shapeName);
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
}
