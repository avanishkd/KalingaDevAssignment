package com.mindtree.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mindtree.entity.Circle;
import com.mindtree.entity.Rectangle;
import com.mindtree.entity.Shape;

public class Main {

	private static SessionFactory sessionFactory;

	public static void main(String[] args) {

		try {

			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Exception e) {
			System.out.println(e);
		}

		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();
		Shape shape = new Shape("Sqaure");
		Rectangle rectangle = new Rectangle("Rectangle", 10, 20);
		Circle circle = new Circle("Circle", 4);
		session.save(shape);
		session.save(rectangle);
		session.save(circle);
		session.getTransaction().commit();
		session.close();

	}
}
