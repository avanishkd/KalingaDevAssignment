package com.mindtree.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UtilityConn {

	private static SessionFactory sessionFactory;

	public static Session getSession() {

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Exception e) {
			System.out.println(e);
		}
		Session session = sessionFactory.openSession();
		return session;
	}

	public static void closeSession(Session session) {
		session.close();
	}
}
