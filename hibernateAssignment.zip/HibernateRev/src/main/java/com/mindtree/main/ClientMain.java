package com.mindtree.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.mindtree.configuration.HibernateUtil;
import com.mindtree.entity.User;

public class ClientMain {

	public static void main(String[] args) {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		// Session session=UtilityConn.getSession();
		// session.beginTransaction();
		// User u=new User("rohan","Banglore");
		// session.save(u);
		// session.getTransaction().commit();
		// session.close();

		// User u = new User("ronaldo", "portugal");
		// session.saveOrUpdate(u);
		// session.getTransaction().commit();

		// User u=new User();
		// u.setId(1);
		// u.setName("Ronaldo");
		// u.setLocation("Real Madrid");
		// session.update(u);
		// session.getTransaction().commit();

		// HQL Practice
		// Query query=session.createQuery("update User set )

		Query query = session.createQuery("from User");
		List<User> l = query.list();
		for (User u : l) {
			System.out.print(u.getId()+" "+u.getName()+" "+u.getLocation());
			System.out.println();
		}

		//Named Parameters
		Query query1=session.createQuery("from User where name=:getName");
		query1.setParameter("getName","rohan");
		List<User> l1=query1.list();
		for(User u:l1)
		{
			System.out.print(u.getId()+" ");
			System.out.print(u.getName());
		}
		System.out.println();
		Query query2=session.createQuery("select name from User where id=:getId");
		query2.setParameter("getId", 1);
		List<String> l2=query2.list();
		for(String u:l2)
		{
			System.out.println(u);
		}
		
		
		session.getTransaction().commit();
		// Close Connection
		HibernateUtil.shutdown();

	}

}
